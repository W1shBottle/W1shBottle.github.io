# Java工单与Python Agent阶段学习计划

更新：2026-11-14。继续设备运维工单项目；不删除既有代码、不把Java整体改写为Python。每天约3小时、每周弹性安排；下列阶段和学习次数是拆分参考，不是完成期限。

**Java工单后端（A）与Python基础（Y）并行 → Python模型调用（B）→ 只读Agent（G）→ 知识检索与评测（C）→ 按条件与Java联调。** A/Y并行；B/G使用假数据即可提前练习。真正连接受限的用户工单数据前，Java端和服务间必须完成身份、资源范围和接口授权。评测从第一次模型调用开始。

## 当前进度与证据

截至2026-11-14核对源码与学习记录：文件版Web已有查询和创建；MyBatis数据库练习接口已有查询、创建和自增主键回填。学习者11月9日跟练并亲自POST得到id=9；11月13日助手为创建过程补事务，并在隔离H2环境运行25项JUnit与17个Demo，这不代表本人已独立掌握，也不等于真实MySQL复测。派单Mapper条件UPDATE、仓库和Service方法已有部分代码，但Controller派单接口、状态冲突与端到端验收未完成。认证授权、解决/验收、Python Agent与真实模型调用均未完成。

`/api/tickets`仍使用文件仓库；`/api/db/tickets`是数据库练习接口。不要把Mapper里已有的派单SQL当成HTTP派单流程已经完成，也不把助手的隔离测试算为独立掌握。

## 项目要做成什么样

用户说：“查一下我的打印机工单，告诉我当前进度，并根据设备资料给出可参考的下一步。”

1. Java工单系统负责用户、工单、MySQL、业务校验和授权，提供明确的只读接口。
2. Python负责模型调用、工具选择、任务步骤、结果整合和引用；不直接执行任意SQL或更改工单。
3. 资料和工单无法确定时提示缺少信息；有多条结果就追问。模型回答标注工单编号、资料来源及限制。
4. 简单页面或HTTP工具展示问题、步骤和答案即可，不依赖复杂前端或真实设备。

首个实验只用自造假数据；Java和Python的HTTP联调放到双方各自能跑后。Java接口仍未有权限时，只能使用本机隔离演示数据，不能标榜“已保障用户权限”或接入真实敏感数据。

## 阶段与验收

| 阶段 | 亲手交付 | 达标证据 |
| --- | --- | --- |
| A Java工单业务 | 读懂现有事务与数据库创建；逐步完成派单、状态与必要鉴权 | 能独立画请求链并解释回滚；派单接口、失败分支及授权按实际结果记录 |
| Y Python基础 | venv、数据结构、函数/异常、JSON/HTTP；用虚构工单写查询小程序 | 自己写并调试按ID查询和空结果；解释Java Map/List与Python dict/list的区别 |
| R Redis核心与项目实践 | 学数据结构、过期、Python连接；逐步加虚构工单缓存和Agent会话记忆 | 自己解释命中/失效、回源与会话隔离，验证过期与Redis不可用的处理 |
| B Python模型调用 | 先用虚构数据请求一个模型，返回摘要和待补充信息；模拟错误 | 保存真实调用与模拟测试各一份证据，校验结构、超时与错误；没有API时仅标契约测试 |
| G Python只读Agent | 先对假数据接查询工具，完成查找→追问/详情→回答，记录步骤 | 真实模型发出工具调用、Python执行；无结果、坏参数、超时和步数限制可复现 |
| C 资料与评测 | 维护少量自编设备资料，检索并引用；用固定任务集改进 | 引用可定位；区分检索、工具、生成错误，记录真实样本数、耗时与用量 |
| L 安全联调 | Java提供经授权的只读工单接口，Python通过HTTP调用 | 隔离演示数据、真实身份与授权已验证；无权请求不能读取；超时/故障可解释 |


## 接下来的六个学习单元

每单元可以拆成多次，不能独立完成就放慢；Python与Java交替，不要求按日历赶工。

| 顺序 | Java项目任务 | Python / Agent任务 | 自己能验证的结果 |
| --- | --- | --- | --- |
| 1 | 打开DatabaseTicketRepository.create，画调用链，解释事务与插入后回查；区分H2测试和MySQL | 安装/确认Python解释器与venv，运行hello；比较Python变量与Java类型 | 能说明入口、环境和事务失败路径；不新增正式数据库写入 |
| 2 | 读TicketMapper.assignTicket、Repository.assign、CommandService.assign，找出已有与未接部分 | list/dict/for/if：使用自己编造的2—3条工单，筛选OPEN | 能独立修改一个筛选条件，预测空结果再运行 |
| 3 | 理解条件UPDATE、影响行数0/1与状态冲突；再补Controller及404/409设计 | 函数、参数、返回值、None、异常：按ID查询假工单 | 查到返回数据、查无提示，不能把None当工单 |
| 4 | 用隔离数据验证派单与重复派单；解释事务，继续授权设计 | venv/pip、模块和JSON；将假数据读入，写一个简单测试 | 说清环境/依赖和坏JSON处理；不读取私人工单 |
| 5 | 练习GET/POST、JSON和接口错误；理解业务校验归属Java | HTTP基础，FastAPI做health与假工单查询接口 | 正常、参数错误、查无结果均可复现 |
| 6 | 继续完成必要角色/归属和测试，不公开未授权开发接口 | 在隔离演示中调用模型API生成摘要；配置密钥/预算/超时 | 真实模型调用与模拟故障分别记录；无可用API则只完成本地契约 |

**下一次亲手做：** 先读 `DatabaseTicketRepository.create`，画出POST→Service→Repository→Mapper→MySQL调用链，解释 `@Transactional` 生效条件和失败回滚；同时开始Python基础，使用虚构工单列表练变量、列表、字典与函数。理解后继续数据库派单的接口和404/409；不在真实数据库上做未隔离的写入实验。

## 按阶段看网课与做练习

学习方式：每次只安排当前任务相关的1—2集，给出视频链接、分P、时长和要留意的问题；看完由学习者反馈、提问，再回到现有工单项目独立做小练习。下面时长约数仅为视频播放时长，不含暂停和练习；不要求从头看完大课。看过、跟练和能独立完成分开记录。以下是依据公开简介和选集目录筛选，当前环境受B站访问限制，未逐段播放；若选集顺序或时长变化，以标题为准。配套付费服务不作为学习前提，安装与API版本以官方文档和本机环境为准。

1. **现在：Java事务，先看一集。** 黑马JavaWeb [P101「事务管理-介绍与操作」](https://www.bilibili.com/video/BV1yGydYEE3H/?p=101)约20分钟；接着看 [P102「Spring事务管理-介绍」](https://www.bilibili.com/video/BV1yGydYEE3H/?p=102)约16分钟。看后对照 `DatabaseTicketRepository.create`，画POST→Service→Repository→Mapper→MySQL调用链，说出出错时为什么需要回滚；结合[Spring事务官方说明](https://docs.spring.io/spring-framework/reference/data-access/transaction/declarative/annotations.html)核对代理和异常规则。先理解，不操作真实业务数据。
2. **现在并行：Python基础（Y）。** 黑马Python课先看 [P10「变量」](https://www.bilibili.com/video/BV1sHU9BmEne/?p=10)约19分钟和 [P13「数据类型」](https://www.bilibili.com/video/BV1sHU9BmEne/?p=13)约14分钟；再按练习需要看 [P22 if](https://www.bilibili.com/video/BV1sHU9BmEne/?p=22)、[P30 for](https://www.bilibili.com/video/BV1sHU9BmEne/?p=30)、[P37列表](https://www.bilibili.com/video/BV1sHU9BmEne/?p=37)、[P52字典](https://www.bilibili.com/video/BV1sHU9BmEne/?p=52)和[P58函数](https://www.bilibili.com/video/BV1sHU9BmEne/?p=58)。每次用2—3条虚构工单做筛选或查询；解释Python的list/dict与Java集合的区别。先检查现有Python，按[官方venv教程](https://docs.python.org/zh-cn/3/library/venv.html)建立项目隔离环境，不重装或替换现有环境。
3. **Python集合基础后：Redis基础（R01）。** 选择黑马Redis课的 [P4「认识Redis」](https://www.bilibili.com/video/BV1cr4y1671t/?p=4)约7分钟、[P9「通用命令」](https://www.bilibili.com/video/BV1cr4y1671t/?p=9)约12分钟、[P10「String类型」](https://www.bilibili.com/video/BV1cr4y1671t/?p=10)约13分钟；分次再看 [P12 Hash](https://www.bilibili.com/video/BV1cr4y1671t/?p=12)约12分钟、[P13 List](https://www.bilibili.com/video/BV1cr4y1671t/?p=13)约15分钟。学完在隔离环境用假数据练 `SET/GET/EXPIRE/TTL`、`HSET/HGETALL`、`RPUSH/LRANGE`，预测并观察过期。课程录于2022年，基础概念仍可参考；安装、客户端和版本以届时官方文档为准，不照搬Linux安装到Windows，也不需要现在安装。
4. **Python函数/环境就绪后：Python访问Redis（R02）。** 看 [Python操作Redis P9](https://www.bilibili.com/video/BV16vFPevEt6/?p=9)约15分钟，随后参照[Redis官方redis-py入门](https://redis.io/docs/latest/develop/clients/redis-py/)完成假数据读写、过期、连接超时和错误处理；理解返回bytes与字符串的区别。服务暂不可用时记录错误，不把模拟结果算成真实连接。
5. **有Java查询后：工单缓存（R03）。** 看黑马Redis课的 [P35「什么是缓存」](https://www.bilibili.com/video/BV1cr4y1671t/?p=35)约10分钟、[P36「添加商户缓存」](https://www.bilibili.com/video/BV1cr4y1671t/?p=36)约14分钟，再看 [P38「缓存更新策略」](https://www.bilibili.com/video/BV1cr4y1671t/?p=38)约26分钟。模仿思路给隔离的虚构设备查询加缓存：先读Redis，未命中读MySQL并设置TTL；更新MySQL后删除对应缓存；Redis故障回落数据库。按[官方Cache-Aside说明](https://redis.io/docs/latest/develop/use-cases/cache-aside/)说明并发时可能出现短暂不一致，TTL只是兜底，不声称强一致。真实私有工单需先认证授权，不能用公共缓存键绕过权限。
6. **完成假数据Agent后：会话记忆（R04）。** 用Python的 `redis-py` 将虚构对话按session分开存入List、限制长度并设置TTL，验证对话顺序、会话隔离、过期和Redis不可用时的短暂内存降级或明确错误；这只是上下文记忆练习，不等于永久保存或已具备身份授权。初版模型调用和只读Agent可以先用内存完成，不必等Redis。
7. **后续需要HTTP和Agent时。** FastAPI先看 [P3「第一个程序」](https://www.bilibili.com/video/BV1rgd3B6ErE/?p=3)约19分钟，再按需看[P7路径参数](https://www.bilibili.com/video/BV1rgd3B6ErE/?p=7)和[P11请求体](https://www.bilibili.com/video/BV1rgd3B6ErE/?p=11)，只做假工单查询接口。模型与工具先理解原生调用，再参考LangChain课的 [P6「模型调用」](https://www.bilibili.com/video/BV15jug6yEyM/?p=6)、[P13「结构化输出」](https://www.bilibili.com/video/BV15jug6yEyM/?p=13)、[P14「工具调用」](https://www.bilibili.com/video/BV15jug6yEyM/?p=14)；框架版本变化时查[官方Agent文档](https://docs.langchain.com/oss/python/langchain/agents)，不为了看课一次装完全部依赖。

Redis先掌握上述基础和两个实际场景；集群、分布式锁、消息队列、底层源码与性能调优等在具体岗位或项目需要时再扩展，不与首个Agent串行绑定。

## Python从零学到什么程度

顺序：解释器与虚拟环境 → 字符串、列表、字典、循环 → 函数和模块 → 异常与调试 → JSON/HTTP → FastAPI接口 → 模型API和工具调用。以Y01—Y06的项目练习验收；不要求预先学完Python高级语法、算法研究或机器学习训练。

和Java对照：`list`≈常用列表操作、`dict`≈键值映射、`None`表达缺值、异常仍需处理；语言细节并不完全相同，不能按名称当作一模一样。只用模拟工单数据。参考[Python官方教程](https://docs.python.org/zh-cn/3/tutorial/)和[FastAPI入门](https://fastapi.tiangolo.com/zh/tutorial/first-steps/)，版本与依赖在实际安装时核对。

## B/G：先做可运行的小Agent

1. Python内存里构造假工单，写 `find_ticket(ticket_id)` 和 `list_tickets(status)`，正常、无数据、非法参数均能处理。
2. 调用一个模型API：先让它理解用户问题并输出摘要，再让它实际请求一个工具；由Python按工具名/参数调用函数，把结果送回模型。
3. 加入有限步数、超时、失败提示和过程记录。先做一个Agent、一两个只读工具；LangChain可辅助模型/工具集成，LangGraph在确需多步状态时引入。
4. 对话歧义时追问，能展示实际工具调用记录和任务结果。模型输出不是数据库事实，也不自动获得业务权限。

先用假数据不要求真实用户登录；这只是学习原型，不宣传为有权限的业务系统。模型服务能看到发送给它的内容，因此只用虚构样本，key从环境变量获取，不写入代码或日志。

## 与Java联调和权限边界

Python先调用本机、隔离数据上的只读接口，记录HTTP状态、超时及错误，不先做写入。真实多用户场景必须先有Java认证和资源归属校验，以及服务间身份传递；服务端从可信会话或明确设计的服务凭据取得身份，不能信任模型生成的userId。认证缺失时只做假数据实验，不对公网开放开发接口。

需要时再由Java请求Python提供的Agent接口；两个进程带来启动、配置、依赖版本、超时、日志和联调成本，先分别调通，再连接。工具禁止模型拼任意SQL、执行系统命令或任意URL；写工具留到人工确认、重新鉴权、状态和幂等均能验证后。

## 知识检索与评测

准备10—20条自编虚构维护资料，记录资料ID、版本、设备范围、段落。先做关键词检索并给出处，语义效果不足时再试Embedding与向量库；查无依据就说明不足。资料本身不授予权限。

从约12—20条正常、模糊、无结果和错误输入开始，逐步扩展约30条Agent任务，区分开发集与留出集。分别记录检索命中、工具选择和参数、任务完成、引用依据、失败原因、延迟和真实用量/费用；缺费用写未知。先定判断标准，再比较修改前后，不能只保留成功截图。

## 后续按需与求职

Java基础、SQL、Git和常见数据结构继续训练；Redis基础及缓存、会话练习是计划内主线，基础可以在Python集合后穿插，缓存和会话跟随项目逐步实现。MCP、SubAgent、模型路由、微服务和模型训练在单Agent可靠后按岗位补。Python项目要能独立开发和调试，不能只列框架名。Java方向岗位与Python Agent方向分别对照岗位真实要求；查看届别、到岗天数和实习期，不保证录用。

参考：[Python官方教程](https://docs.python.org/zh-cn/3/tutorial/) · [FastAPI入门](https://fastapi.tiangolo.com/zh/tutorial/first-steps/) · [LangChain Agents](https://docs.langchain.com/oss/python/langchain/agents) · [LangGraph](https://docs.langchain.com/oss/python/langgraph/overview)。具体依赖版本在实际接入时确认兼容，不为了追新重装现有Java环境。
