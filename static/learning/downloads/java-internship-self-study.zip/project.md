# 设备运维工单平台项目说明

> 本页说明项目路线；当前实现与验收请配合[项目文档](https://wishbottle.cn/learning/project-docs/)阅读。计划中的能力不代表已经实现或掌握。

更新：2026-10-26。沿用既有 ops-ticket / JavaProject，在同一个设备运维工单主题中学习Java后端与AI应用开发。项目使用虚构设备资料，不依赖硬件接入；以开发、测试与交付能力为重点。

## 现有成果与实际起点

当前是 Java 21＋Maven 的本地控制台项目：Ticket、Service、Repository、两种仓库、UTF-8 文件保存与恢复、控制台菜单、17 项 JUnit 和可运行 JAR。MySQL 8.0.44 的独立练习库 ops_ticket_dev 已有设备、用户和工单三表，正在练习 SQL；Java 还没有数据库驱动/访问代码。HTTP、登录权限、完整处理验收、AI、RAG、Agent 均未实现。

现有 Java 结构不算复杂，可继续用。需要改的是后续范围：旧计划把六表、评论、退回、看板及众多扩展排在 AI 前，现在将首版收敛为核心业务和必需工程能力，随即接入一个可评估的 AI 功能。

已有源码/运行结果不等于学习者独立掌握。当前能根据学习记录确认对象引用、Map 覆盖、编号接续、路径和若干异常概念；接口接线有助手修复记录。SQL 中打印机＋OPEN＋IS NULL组合已由学习者提交语句和正确结果；JOIN已讲解并保存，完整执行和独立变体仍待验收。具体状态见 [学习时间线](https://wishbottle.cn/learning/#progress)，不因本次改计划自动增加完成项。

## 同一个项目的三个主阶段

| 阶段 | 交付范围 | 验收之后再做什么 |
| --- | --- | --- |
| A1 最小后端业务 | Java＋Spring Boot＋MyBatis＋MySQL，报修创建→派单→解决→验收关闭，详情/必要筛选 | 核心数据能持久化，能解释请求链；仍在本机教学 |
| A2 基础工程 | 会话认证、三角色与归属权限、参数与异常、事务日志、重复/并发请求、关键测试、部署排错 | 小版本可运行可部署，能独立改一项业务后进入 B |
| B 一个真实 AI 功能 | 结构化工单摘要、分类建议和待补充信息，用户决定是否采用 | API/结构校验/超时与错误降级可运行，真实调用有证据，进入 C |
| C 验证与改进 | 固定案例、无 AI 基线、内容质量、失败、延迟、用量和成本，改进后复验 | 用结果判断是否补 RAG、受控 Agent 或其他缺口 |

A1/A2 合在“Java 后端业务”主阶段中，分别对应最小业务与基础工程；评估从 B 首次调用就开始，C 专门整理并改进。Agent 不是必须从头做的第四个项目。按可检查的门槛推进，不承诺几周掌握；原 20 周文件名保留为教材索引。

## 第一版业务边界

设备来自虚构园区/实验室记录，无真实硬件连接。只保留三种角色：

| 角色 | 首版职责 | 不可越过的边界 |
| --- | --- | --- |
| REPORTER 报修人 | 选启用设备、创建、查自己的工单、验收 | 不能冒充别人报修、查询别人记录或自行派单 |
| ENGINEER 工程师 | 查分给自己的工单、提交非空处理说明 | 不能处理别人名下工单或代报修人验收 |
| ADMIN 管理员 | 查询、给 OPEN 工单指定启用工程师 | 不能随意设置状态或代报修人验收 |

流程为 OPEN→IN_PROGRESS→RESOLVED→CLOSED。首版不做验收退回、评论、公开注册、全套设备/用户后台、统计大屏。演示先用接口工具，随后可加简洁页面；不要求先学大型前端框架。

现有三表保留，A 阶段再加 ticket_action_log；处理说明存 resolve 动作 note，状态与日志同事务。暂不建 ticket_comment/ticket_resolution。创建重试用请求键，状态操作用前置状态＋期望版本；SQL 中 version 字段存在并不代表这些保护已实现。

具体规则、接口与验收不在本页重复维护，以项目 [需求](https://wishbottle.cn/learning/project-requirements/)、[设计](https://wishbottle.cn/learning/project-design/)、[验收](https://wishbottle.cn/learning/project-verification/) 为准。

## 第一项 AI 功能为什么这样选

工单经常只有杂乱描述。已有 title/description 就能支持“整理现象、给分类建议、指出缺的信息”，无需先做知识库或购置硬件。第一版对有权读取的工单返回 summary、category、missingInformation；category 限定 DISPLAY/PRINTING/HVAC/OTHER/UNKNOWN，只作为建议，不自动入库派单。首版只展示/复制参考，不直接写回标题。当前 rename 只有控制台和 Service 实现；以后要做人工采纳入口，先补明确权限、状态、版本和日志规则的 HTTP 接口。

这项功能能够练习真正的模型请求、响应结构、输入边界、成本和失败处理。AI 无依据时不编造型号/维修结论；模型不可用时正常报修、派单和验收继续运行。第一版不能声称故障诊断专家或自主维修 Agent。

B 开始前再选择供应商、模型与费用上限，准备本地环境变量；当前未配置或真实验证任何模型。Java 先实现清晰的 ModelClient 边界，调用 API，不强行拆 Python 服务。模拟响应只能验证解析与降级，不能充当真实模型效果。

## RAG 和 Agent 的加入条件

- 只有出现“需要根据手册给出处”的问题，才增加授权资料导入、来源版本、检索与引用；无相关依据时说明没有查到，记录召回和生成两种失败。
- 只有需要自然语言查询本人/授权范围内工单，才增加受控只读工具。工具复用 Service，程序校验权限和参数，不让模型拼任意 SQL。
- 只读工具稳定并有多步骤需求后，才加有限调用次数、上下文和失败处理。写入工具必须展示具体动作供确认，执行时重新检查权限/版本/参数，不能绕过 Java 业务规则。
- 不把 Redis、MQ、微服务、Kubernetes、MCP、多 Agent、本地训练或大规模向量库作为 AI 的先修课。

## 技术与学习方式

沿用 Java 21、Maven 和当前 MySQL 8.0.44 练习环境，不为了路线调整现在升级数据库或改依赖。先学 SQL/JOIN/事务，再写短 JDBC 查询，之后引入 Spring Boot＋MyBatis。到框架课才按[官方兼容表](https://mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure/)固定支持的版本。认证优先 Spring Security＋Session Cookie，保留 CSRF，使用框架密码编码器；不额外堆 JWT/复杂鉴权体系。

两种 AI 学习分开：AI 辅助编程可用于解释/评审/排错，但每个模块要自己读调用链、独立改需求并验证；产品内 AI 功能则必须自己接入、测试真实 API 和失败路径。安排少量高价值测试，避免重复抄同类断言；数据库事务必须用真实 MySQL 验证，不能只看 Mock。

每次约 3 小时是时间预算，不是作业定额：先回忆已有代码，再讲一个新概念、独立写一个小变更、验证并记录帮助和困难。每个阶段至少独立实现/修改一个功能、解释一次设计、排查一个故障。完整任务见 [阶段学习计划](./schedule.md)。

## 求职匹配与信息边界

后端能力仍是 AI 应用的基础，不能从技术热度判断“纯后端已落后”。2026-10-26 核查的[海康 Java 实习岗位](https://talent.hikvision.com/home/socity/position?postId=3DBC4346A3391150639BCB4895723F64)仍覆盖 Java、Spring、MyBatis、SQL、测试与部署；[质量管理软件实习](https://talent.hikvision.com/home/socity/position?postId=80E877130AFCA23529A8391F624FA447)也要求后端框架和 SQL，并提 AI 辅助开发。[大华 AI 应用开发岗位](https://dahua1.zhiye.com/campus/detail?jobAdId=cc425147-ec13-45d8-b704-f4c6632f0f89)可作 Java/AI 工程能力参照，但该岗位明确限定 2027 届，申请时须核对自己的毕业届别；详情信息来自官网搜索索引。

上述不是 2027 暑期岗位保证。每次投递核对本科门槛、毕业届别、杭州地点、每周出勤与连续实习时长。简历分别写已实现业务、真实 AI 验证、个人独立贡献和限制；没有测出的性能/成本不能编造。第二个项目等第一项目完成及岗位缺口明确后再决定。

官方技术参考：[结构化输出仍需校验](https://docs.spring.io/spring-ai/reference/api/structured-output/converters.html) · [工具调用由应用控制执行](https://docs.spring.io/spring-ai/reference/api/tools.html)。引用用于设计判断，不表示本项目已使用 Spring AI。
