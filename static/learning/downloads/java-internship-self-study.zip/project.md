# 设备运维工单平台项目说明

> 本页说明项目路线；当前实现与验收请配合[项目文档](https://wishbottle.cn/learning/project-docs/)阅读。计划中的能力不代表已经实现或掌握。

更新：2026-11-14。同一工单项目继续使用Java/Spring Boot/MySQL，Python作为后续Agent主语言，不重写已完成的业务。

## 实际起点

截至2026-11-14核对源码与学习记录：文件版Web已有查询和创建；MyBatis数据库练习接口已有查询、创建和自增主键回填。学习者11月9日跟练并亲自POST得到id=9；11月13日助手为创建过程补事务，并在隔离H2环境运行25项JUnit与17个Demo，这不代表本人已独立掌握，也不等于真实MySQL复测。派单Mapper条件UPDATE、仓库和Service方法已有部分代码，但Controller派单接口、状态冲突与端到端验收未完成。认证授权、解决/验收、Python Agent与真实模型调用均未完成。

## 目标和阶段

Java工单后端（A）与Python基础（Y）并行 → Python模型调用（B）→ 只读Agent（G）→ 知识检索与评测（C）→ 按条件与Java联调。

| 阶段 | 亲手交付 | 达标证据 |
| --- | --- | --- |
| A Java工单业务 | 读懂现有事务与数据库创建；逐步完成派单、状态与必要鉴权 | 能独立画请求链并解释回滚；派单接口、失败分支及授权按实际结果记录 |
| Y Python基础 | venv、数据结构、函数/异常、JSON/HTTP；用虚构工单写查询小程序 | 自己写并调试按ID查询和空结果；解释Java Map/List与Python dict/list的区别 |
| B Python模型调用 | 先用虚构数据请求一个模型，返回摘要和待补充信息；模拟错误 | 保存真实调用与模拟测试各一份证据，校验结构、超时与错误；没有API时仅标契约测试 |
| G Python只读Agent | 先对假数据接查询工具，完成查找→追问/详情→回答，记录步骤 | 真实模型发出工具调用、Python执行；无结果、坏参数、超时和步数限制可复现 |
| C 资料与评测 | 维护少量自编设备资料，检索并引用；用固定任务集改进 | 引用可定位；区分检索、工具、生成错误，记录真实样本数、耗时与用量 |
| L 安全联调 | Java提供经授权的只读工单接口，Python通过HTTP调用 | 隔离演示数据、真实身份与授权已验证；无权请求不能读取；超时/故障可解释 |


目标场景：查询工单进度，必要时追问设备信息，检索维护资料并给出有出处的建议。前期全用虚构数据，真实业务联调需Java完成用户授权及服务间身份校验。

## 第一版业务边界

设备来自虚构园区/实验室记录，无真实硬件连接。只保留三种角色：

| 角色 | 首版职责 | 不可越过的边界 |
| --- | --- | --- |
| REPORTER 报修人 | 选启用设备、创建、查自己的工单、验收 | 不能冒充别人报修、查询别人记录或自行派单 |
| ENGINEER 工程师 | 查分给自己的工单、提交非空处理说明 | 不能处理别人名下工单或代报修人验收 |
| ADMIN 管理员 | 查询、给 OPEN 工单指定启用工程师 | 不能随意设置状态或代报修人验收 |

流程为 OPEN→IN_PROGRESS→RESOLVED→CLOSED。首版不做验收退回、评论、公开注册、全套设备/用户后台、统计大屏。演示先用接口工具，随后可加简洁页面；不要求先学大型前端框架。

现有三表保留，A 阶段再加 ticket_action_log；处理说明存 resolve 动作 note，状态与日志同事务。暂不建 ticket_comment/ticket_resolution。创建重试用请求键，状态操作用前置状态＋期望版本；SQL 中 version 字段存在并不代表这些保护已实现。

具体规则、接口与验收不在本页重复维护，以项目 [需求](https://wishbottle.cn/learning/project-requirements/)、[设计](https://wishbottle.cn/learning/project-design/)、[验收](https://wishbottle.cn/learning/project-verification/) 为准。

## 首个Python模型功能与Agent

用自造工单产生summary/category/missingInformation；先Python脚本加模拟数据和模拟故障，再尝试真实模型API。输出只展示，不自动写库或派单；模型调用失败不影响Java业务。

做一个查询假工单的Python工具，让模型请求调用、程序校验并执行、把结果反馈给模型；再增加多步查询/追问、限步、超时、日志。根据需要学习LangChain、LangGraph，先不要求多Agent。

后续Java只读业务接口经认证授权后，再使用Python HTTP客户端安全接入；验证跨用户拒绝、超时与空结果。模型不能拼任意SQL，也不能传入用户身份冒充授权。维护资料使用虚构内容并记录来源/版本与引用，真假模型结果和模拟失败分别记录。

真实业务联调前，不公开当前无授权的开发接口，不上传真实敏感工单。MCP、自动派单、Redis、微服务和训练模型按需要后置。

## 技术与学习方式

沿用 Java 21、Maven；当前MySQL8.4.13与Connector/J26.10.0已经过独立恢复和连接验证。SQL、短JDBC和MyBatis查询/创建已有跟练；下一步理解创建事务与未完成的派单流程，同时开始Python基础，不重复升级现有环境。框架版本到接入时按官方兼容表固定；认证仍优先Spring Security＋Session Cookie，保留CSRF并使用框架密码编码器。

两种 AI 学习分开：AI 辅助编程可用于解释/评审/排错，但每个模块要自己读调用链、独立改需求并验证；产品内 AI 功能则必须自己接入、测试真实 API 和失败路径。安排少量高价值测试，避免重复抄同类断言；数据库事务必须用真实 MySQL 验证，不能只看 Mock。

每次约 3 小时是时间预算，不是作业定额：先回忆已有代码，再讲一个新概念、独立写一个小变更、验证并记录帮助和困难。每个阶段至少独立实现/修改一个功能、解释一次设计、排查一个故障。完整任务见 [阶段学习计划](./schedule.md)。

## 求职匹配与信息边界

后端能力仍是 AI 应用的基础，不能从技术热度判断“纯后端已落后”。2026-10-26 核查的[海康 Java 实习岗位](https://talent.hikvision.com/home/socity/position?postId=3DBC4346A3391150639BCB4895723F64)仍覆盖 Java、Spring、MyBatis、SQL、测试与部署；[质量管理软件实习](https://talent.hikvision.com/home/socity/position?postId=80E877130AFCA23529A8391F624FA447)也要求后端框架和 SQL，并提 AI 辅助开发。[大华 AI 应用开发岗位](https://dahua1.zhiye.com/campus/detail?jobAdId=cc425147-ec13-45d8-b704-f4c6632f0f89)可作 Java/AI 工程能力参照，但该岗位明确限定 2027 届，申请时须核对自己的毕业届别；详情信息来自官网搜索索引。

上述不是 2027 暑期岗位保证。每次投递核对本科门槛、毕业届别、杭州地点、每周出勤与连续实习时长。简历分别写已实现业务、真实 AI 验证、个人独立贡献和限制；没有测出的性能/成本不能编造。第二个项目等第一项目完成及岗位缺口明确后再决定。

官方技术参考：[结构化输出仍需校验](https://docs.spring.io/spring-ai/reference/api/structured-output/converters.html) · [工具调用由应用控制执行](https://docs.spring.io/spring-ai/reference/api/tools.html)。引用用于设计判断，不表示本项目已使用 Spring AI。
